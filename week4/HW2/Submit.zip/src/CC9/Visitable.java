package CC9;

public interface Visitable{
    public void accept(Visitor visitor);
}
